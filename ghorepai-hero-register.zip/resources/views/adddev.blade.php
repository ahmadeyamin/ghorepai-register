@extends('layouts.app')


@section('content')
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<div class="add_dev_sec">
    <div class="w-container">
       <div class="">
          <h2>We Have A Big Dream But Don&#x27;t Have A Big Team :(</h2>
          <br>
          <h2>So We decided to outsource some developers or Collaborators :)</h2>
          <p>‍</p>
          <h4>If you are interested to work with us for this project :)</h4>
          <p>We Have some big things for you. but you have to enough Knowledge about what we are trying to build. so please check you stage and contact us :)</p>
          <p>‍</p>
          <h2>Stage 1 :</h2>
          <ul role="list">
             <li>SEO</li>
             <li>Facebook Marketing</li>
             <li>off page sEO</li>
             <li>Basic Content writing</li>
          </ul>
          <p>‍</p>
          <h2>Stage 2 :</h2>
          <ul role="list">
             <li>HTML &amp; CSS</li>
             <li>Javascript</li>
             <li>Bootstrap</li>
             <li>basic web design</li>
             <li>jquery</li>
          </ul>
          <h2>Stage 3 :</h2>
          <ul role="list">
             <li>PHP</li>
             <li>VUE jS</li>
             <li>Advance interactive UI Design.</li>
             <li>basic mysql</li>
          </ul>
          <p>‍</p>
          <h2>Stage 4 :</h2>
          <ul role="list">
             <li>Laravel </li>
             <li>Github</li>
             <li>Livewire</li>
             <li>Websocket</li>
             <li>Google Map API</li>
             <li>basic web design</li>
             <li>PWA + TWA</li>
             <li>Advance MySql</li>
             <li>Work with API</li>
             <li>VUE js or svelte js</li>
             <li>onesignal push notifications</li>
             <li>algolia Search </li>
          </ul>
          <p>‍</p>
          <h3>if you have any of this Specification feel free to Contact us. </h3>
          <h1>our phone : <a href="tel: +8801999050360">01999050360</a></h1>
          <p>‍</p>
          <p>‍</p>
          <p>‍</p>
          <h2>‍</h2>
          <p>‍</p>
       </div>
    </div>
 </div>
@endsection


@push('js')
@livewireScripts
@endpush

@push('css')
@livewireStyles
@endpush
