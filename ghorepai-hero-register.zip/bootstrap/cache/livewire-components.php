<?php return array (
  'delivery-hero' => 'App\\Http\\Livewire\\DeliveryHero',
);